item contains
