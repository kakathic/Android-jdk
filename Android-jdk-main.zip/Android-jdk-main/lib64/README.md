Item contains
